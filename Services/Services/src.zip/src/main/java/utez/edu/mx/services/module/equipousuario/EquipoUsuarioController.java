package utez.edu.mx.services.module.equipousuario;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import utez.edu.mx.services.kernel.AppiResponse;

@RestController
@RequestMapping("/sgp-api/equipo-usuario")
@CrossOrigin(origins = "*")
public class EquipoUsuarioController {

    private final EquipoUsuarioService equipoUsuarioService;

    public EquipoUsuarioController(EquipoUsuarioService equipoUsuarioService) {
        this.equipoUsuarioService = equipoUsuarioService;
    }

    @PostMapping("/asignar")
    public ResponseEntity<AppiResponse> asignarUsuarioAEquipo(
            @RequestParam Long idEquipo,
            @RequestParam Long idUsuario
    ) {
        return equipoUsuarioService.asignarUsuarioAEquipo(idEquipo, idUsuario);
    }

    @DeleteMapping("/quitar")
    public ResponseEntity<AppiResponse> quitarUsuarioDeEquipo(
            @RequestParam Long idEquipo,
            @RequestParam Long idUsuario
    ) {
        return equipoUsuarioService.quitarUsuarioDeEquipo(idEquipo, idUsuario);
    }
}