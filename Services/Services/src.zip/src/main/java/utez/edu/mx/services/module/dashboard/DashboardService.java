package utez.edu.mx.services.module.dashboard;

import org.springframework.stereotype.Service;
import utez.edu.mx.services.module.proyecto.Proyecto;
import utez.edu.mx.services.module.tarea.Tarea;
import utez.edu.mx.services.module.tarea.TareaRepository;
import utez.edu.mx.services.module.usuario.Usuario;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final TareaRepository tareaRepository;

    public DashboardService(TareaRepository tareaRepository) {
        this.tareaRepository = tareaRepository;
    }

    public DashboardResponseDTO getDashboard(Usuario usuario) {
        List<Tarea> tareas = tareaRepository.findByUsuarioAsignadoIdUsuario(usuario.getIdUsuario());

        int totalTareas = tareas.size();

        int tareasCompletadas = (int) tareas.stream()
                .filter(t -> "COMPLETADA".equalsIgnoreCase(t.getEstado()))
                .count();

        int tareasPendientes = totalTareas - tareasCompletadas;

        Map<Long, List<Tarea>> tareasPorProyecto = tareas.stream()
                .collect(Collectors.groupingBy(t -> t.getProyecto().getIdProyecto()));

        List<DashboardProyectoDTO> proyectos = tareasPorProyecto.entrySet().stream()
                .map(entry -> {
                    List<Tarea> tareasDelProyecto = entry.getValue();

                    long completadas = tareasDelProyecto.stream()
                            .filter(t -> "COMPLETADA".equalsIgnoreCase(t.getEstado()))
                            .count();

                    double porcentaje = tareasDelProyecto.isEmpty()
                            ? 0
                            : (double) completadas / tareasDelProyecto.size() * 100;

                    Proyecto proyecto = tareasDelProyecto.get(0).getProyecto();

                    return new DashboardProyectoDTO(
                            proyecto.getIdProyecto(),
                            proyecto.getNombre(),
                            proyecto.getEstado(),
                            Math.round(porcentaje * 10.0) / 10.0
                    );
                })
                .collect(Collectors.toList());

        return new DashboardResponseDTO(
                usuario.getNombre(),
                usuario.getApellidoPaterno(),
                totalTareas,
                tareasCompletadas,
                tareasPendientes,
                proyectos
        );
    }
}