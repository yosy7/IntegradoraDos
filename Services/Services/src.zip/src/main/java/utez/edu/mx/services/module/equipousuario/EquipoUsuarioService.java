package utez.edu.mx.services.module.equipousuario;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import utez.edu.mx.services.kernel.AppiResponse;
import utez.edu.mx.services.module.equipo.Equipo;
import utez.edu.mx.services.module.equipo.EquipoRepository;
import utez.edu.mx.services.module.usuario.Usuario;
import utez.edu.mx.services.module.usuario.UsuarioRepository;

import java.util.Optional;

@Service
public class EquipoUsuarioService {

    private final EquipoUsuarioRepository equipoUsuarioRepository;
    private final EquipoRepository equipoRepository;
    private final UsuarioRepository usuarioRepository;

    public EquipoUsuarioService(
            EquipoUsuarioRepository equipoUsuarioRepository,
            EquipoRepository equipoRepository,
            UsuarioRepository usuarioRepository
    ) {
        this.equipoUsuarioRepository = equipoUsuarioRepository;
        this.equipoRepository = equipoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional
    public ResponseEntity<AppiResponse> asignarUsuarioAEquipo(Long idEquipo, Long idUsuario) {
        Optional<Equipo> equipoOpt = equipoRepository.findById(idEquipo);
        Optional<Usuario> usuarioOpt = usuarioRepository.findById(idUsuario);

        if (equipoOpt.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("Equipo no encontrado", HttpStatus.BAD_REQUEST));
        }

        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("Usuario no encontrado", HttpStatus.BAD_REQUEST));
        }

        if (equipoUsuarioRepository.existsByEquipoIdEquipoAndUsuarioIdUsuario(idEquipo, idUsuario)) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("El usuario ya pertenece a este equipo", HttpStatus.BAD_REQUEST));
        }

        EquipoUsuario relacion = new EquipoUsuario();
        relacion.setEquipo(equipoOpt.get());
        relacion.setUsuario(usuarioOpt.get());

        equipoUsuarioRepository.save(relacion);

        return ResponseEntity.ok(
                new AppiResponse("Usuario asignado al equipo correctamente", HttpStatus.OK)
        );
    }

    @Transactional
    public ResponseEntity<AppiResponse> quitarUsuarioDeEquipo(Long idEquipo, Long idUsuario) {
        Optional<EquipoUsuario> relacionOpt =
                equipoUsuarioRepository.findByEquipoIdEquipoAndUsuarioIdUsuario(idEquipo, idUsuario);

        if (relacionOpt.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("La relación equipo-usuario no existe", HttpStatus.BAD_REQUEST));
        }

        equipoUsuarioRepository.delete(relacionOpt.get());

        return ResponseEntity.ok(
                new AppiResponse("Usuario removido del equipo correctamente", HttpStatus.OK)
        );
    }
}