package utez.edu.mx.services.module.equipo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import utez.edu.mx.services.kernel.AppiResponse;
import utez.edu.mx.services.module.equipo.dto.EquipoDTO;
import utez.edu.mx.services.module.equipousuario.EquipoUsuario;
import utez.edu.mx.services.module.equipousuario.EquipoUsuarioRepository;
import utez.edu.mx.services.module.usuario.Usuario;
import utez.edu.mx.services.module.usuario.UsuarioRepository;
import utez.edu.mx.services.module.usuario.dto.UsuarioDTO;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EquipoService {

    private final EquipoRepository equipoRepository;
    private final EquipoUsuarioRepository equipoUsuarioRepository;
    private final UsuarioRepository usuarioRepository;

    public EquipoService(
            EquipoRepository equipoRepository,
            EquipoUsuarioRepository equipoUsuarioRepository,
            UsuarioRepository usuarioRepository
    ) {
        this.equipoRepository = equipoRepository;
        this.equipoUsuarioRepository = equipoUsuarioRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional(readOnly = true)
    public ResponseEntity<AppiResponse> findAll() {
        List<EquipoDTO> equipos = equipoRepository.findAll()
                .stream()
                .map(EquipoDTO::new)
                .toList();

        return ResponseEntity.ok(new AppiResponse("Operación exitosa", equipos, HttpStatus.OK));
    }

    @Transactional(readOnly = true)
    public ResponseEntity<AppiResponse> findById(Long id) {
        Optional<Equipo> equipo = equipoRepository.findById(id);

        if (equipo.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("Equipo no encontrado", HttpStatus.BAD_REQUEST));
        }

        return ResponseEntity.ok(
                new AppiResponse("Operación exitosa", new EquipoDTO(equipo.get()), HttpStatus.OK)
        );
    }

    @Transactional(readOnly = true)
    public ResponseEntity<AppiResponse> findMiEquipo(String username) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByUsername(username);

        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new AppiResponse("Usuario no encontrado", HttpStatus.NOT_FOUND));
        }

        Usuario usuario = usuarioOpt.get();
        String rol = usuario.getRol() != null ? usuario.getRol().getNombre().toUpperCase() : "";

        if ("SUPERADMIN".equals(rol)) {
            List<EquipoDTO> equipos = equipoRepository.findAll()
                    .stream()
                    .map(EquipoDTO::new)
                    .toList();

            return ResponseEntity.ok(new AppiResponse("Operación exitosa", equipos, HttpStatus.OK));
        }

        List<EquipoUsuario> relaciones = equipoUsuarioRepository.findByUsuarioIdUsuario(usuario.getIdUsuario());

        List<EquipoDTO> equipos = relaciones.stream()
                .map(EquipoUsuario::getEquipo)
                .distinct()
                .map(EquipoDTO::new)
                .toList();

        return ResponseEntity.ok(new AppiResponse("Operación exitosa", equipos, HttpStatus.OK));
    }

    @Transactional(readOnly = true)
    public ResponseEntity<AppiResponse> findIntegrantesByEquipo(Long idEquipo) {
        List<UsuarioDTO> integrantes = equipoUsuarioRepository.findByEquipoIdEquipo(idEquipo)
                .stream()
                .map(EquipoUsuario::getUsuario)
                .map(UsuarioDTO::new)
                .toList();

        return ResponseEntity.ok(new AppiResponse("Operación exitosa", integrantes, HttpStatus.OK));
    }

    @Transactional(readOnly = true)
    public ResponseEntity<AppiResponse> findMisIntegrantes(String username) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByUsername(username);

        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new AppiResponse("Usuario no encontrado", HttpStatus.NOT_FOUND));
        }

        Usuario usuario = usuarioOpt.get();
        String rol = usuario.getRol() != null ? usuario.getRol().getNombre().toUpperCase() : "";

        if ("SUPERADMIN".equals(rol)) {
            List<UsuarioDTO> usuarios = usuarioRepository.findAll()
                    .stream()
                    .map(UsuarioDTO::new)
                    .toList();

            return ResponseEntity.ok(new AppiResponse("Operación exitosa", usuarios, HttpStatus.OK));
        }

        List<EquipoUsuario> misEquipos = equipoUsuarioRepository.findByUsuarioIdUsuario(usuario.getIdUsuario());

        List<UsuarioDTO> integrantes = misEquipos.stream()
                .flatMap(eu -> equipoUsuarioRepository.findByEquipoIdEquipo(eu.getEquipo().getIdEquipo()).stream())
                .map(EquipoUsuario::getUsuario)
                .distinct()
                .map(UsuarioDTO::new)
                .toList();

        return ResponseEntity.ok(new AppiResponse("Operación exitosa", integrantes, HttpStatus.OK));
    }

    @Transactional
    public ResponseEntity<AppiResponse> save(Equipo equipo) {
        if (equipo.getNombreEquipo() == null || equipo.getNombreEquipo().isBlank()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("El nombre del equipo es obligatorio", HttpStatus.BAD_REQUEST));
        }

        if (equipoRepository.existsByNombreEquipo(equipo.getNombreEquipo())) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("El nombre del equipo ya está en uso", HttpStatus.BAD_REQUEST));
        }

        if (equipo.getFechaCreacion() == null) {
            equipo.setFechaCreacion(LocalDate.now());
        }

        if (equipo.getEstatus() == null || equipo.getEstatus().isBlank()) {
            equipo.setEstatus("ACTIVO");
        }

        Equipo saved = equipoRepository.save(equipo);

        return ResponseEntity.ok(
                new AppiResponse("Equipo registrado exitosamente", new EquipoDTO(saved), HttpStatus.OK)
        );
    }

    @Transactional
    public ResponseEntity<AppiResponse> update(Long id, Equipo equipo) {
        Optional<Equipo> existing = equipoRepository.findById(id);

        if (existing.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("Equipo no encontrado", HttpStatus.BAD_REQUEST));
        }

        if (equipo.getNombreEquipo() == null || equipo.getNombreEquipo().isBlank()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("El nombre del equipo es obligatorio", HttpStatus.BAD_REQUEST));
        }

        if (equipoRepository.existsByNombreEquipoAndIdEquipoNot(equipo.getNombreEquipo(), id)) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("El nombre del equipo ya está en uso", HttpStatus.BAD_REQUEST));
        }

        Equipo e = existing.get();
        e.setNombreEquipo(equipo.getNombreEquipo());
        e.setDescripcion(equipo.getDescripcion());
        e.setLogo(equipo.getLogo());
        e.setEstatus(equipo.getEstatus());

        Equipo updated = equipoRepository.save(e);

        return ResponseEntity.ok(
                new AppiResponse("Equipo actualizado exitosamente", new EquipoDTO(updated), HttpStatus.OK)
        );
    }

    @Transactional
    public ResponseEntity<AppiResponse> delete(Long id) {
        Optional<Equipo> existing = equipoRepository.findById(id);

        if (existing.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new AppiResponse("Equipo no encontrado", HttpStatus.BAD_REQUEST));
        }

        Equipo e = existing.get();
        e.setEstatus("INACTIVO");
        equipoRepository.save(e);

        return ResponseEntity.ok(
                new AppiResponse("Equipo desactivado exitosamente", HttpStatus.OK)
        );
    }
}