package utez.edu.mx.services.module.categoria;

public class CategoriaService {
}
